from django.apps import AppConfig


class PawsConfig(AppConfig):
    name = 'paws'
